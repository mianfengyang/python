from zdb_server import *

if __name__ == "__main__":
    print('※※※※※ ZDB (Lora) Terminal Control Server ※※※※※')
    zdb_server = ZDB_Server()
    zdb_server.run()
